// Year in footer
document.getElementById('year').textContent = new Date().getFullYear();

// Very light fake slider effect: switch active dot (no images rotation for simplicity)
const dots = document.querySelectorAll('.dot');
dots.forEach((d, i) => {
  d.addEventListener('click', () => {
    document.querySelector('.dot.is-active')?.classList.remove('is-active');
    d.classList.add('is-active');
  });
});

// Apply background from inline style variable to actual element
document.querySelectorAll('.hero__slide').forEach(el => {
  const style = getComputedStyle(el).getPropertyValue('--bg').trim();
  if(style) el.style.backgroundImage = style;
});
